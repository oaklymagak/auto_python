import os
# import shelve
# a=os.path.exists('C:\\Windows')
# print a
# print os.path.isdir('C:\\Windows\\System32')
# print os.listdir('.')
# hellofile=open('.\\hello.txt','a')
# hellofile.write('hello world\nmy name is vincent\n')
# hellofile.close()
# hellofile1=open('.\\hello.txt','r')
# hellocontent=hellofile1.readlines()
# print hellocontent
# hellofile1.close()
# shelffile=shelve.open('mydata')
# cat=['zopi','pooka','simon']
# shelffile['cats']=cat
# print type(shelffile)
# print shelffile['cats']
# shelffile.close()
# for foldername,subfolders,filenames in os.walk('.'):
#     print('the current folder is '+foldername)
#     for subfolder in subfolders:
#         print('subfolder of '+foldername+': '+subfolders)
#     for filenames in filenames:
#         print('filename inside '+foldername+': '+filenames)
# print('')
#
# for filename in os.listdir('.\\automate'):
#     if filename.endswith('.txt'):
#         os.unlink(filename)
#         # print(filename)
=import